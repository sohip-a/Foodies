const email = document.getElementById('email');
const password = document.getElementById('password');
const confirmPassword = document.getElementById('confirm_password');
const uniqueId = document.getElementById('username');
const telephoneNumber = document.getElementById('phone');
const signUpButton = document.getElementById('signup-button');
const confirmPasswordError = document.getElementById('confirm_password_error');


function validateRegPage() {
  if (email.value == '') {
    alert('Email is required');
  }
  else if (password.value == '') {
    alert('Password is required');
  }
  else if (/\S+/.test(email.value) === false) {
    alert('Email must not be blank');
    return false;
  }
  const emailRegex = /^\S+@\S+\.\S+$/;
  if (emailRegex.test(email.value) === false) {
    alert('Email format is not valid');
  }

  const regex = /^[0-9]*$/;
  if (regex.test(telephoneNumber.value) === false) {
    alert('phone must no contain any characterss')
  }



  else if (/\S+/.test(password.value) === false) {
    alert('Password must not be blank');
  }
  const passwordRegex = /^(?=.*\d).+$/;
  if (passwordRegex.test(password.value) === false) {
    alert('Password must contain at least one numeric value');
  }
  const passwordRegex1 = /^(?=.*[A-Z]).+$/;
  if (passwordRegex1.test(password.value) === false) {
    alert('Password must contain at least one uppercase letter');
  }
  const passwordRegex2 = /^(?=.*[!@#$%^&*]).+$/;
  if (passwordRegex2.test(password.value) === false) {
    alert('Password must contain at least one special character (!@#$%^&*)');
  }
  else
    return true;
  if (password.value.length < 8) {
    alert('Password must be at least 8 characters long');
  }

  if (confirmPassword.value === '') {
    alert('T13 Confirm Password - Confirm Password must not be blank');
  } else {
    return true;
  }
}

// Login_Page_Validation
//************************************************************************************************* */
// Get form elements
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const showPasswordBtn = document.getElementById('show-password-btn');

// Validation functions
function validateLogin() {
  const emailValue = emailInput.value.trim();
  if (emailValue === '') {
    alert('Email must not be blank');
  } else {
    return true;
  }
  const passwordValue = passwordInput.value.trim();
  if (passwordValue === '') {
    alert('Password must not be blank');
  } else {
    return true;
    //   const passwordType = passwordInput.type;
    // passwordInput.type = passwordType === 'password' ? 'text' : 'password';
    // showPasswordBtn.textContent = passwordType === 'password' ? 'Hide Password' : 'Show Password';
  }

  // validate email already exist in db or not (assuming there is api )
  //   const loginButton = document.querySelector("#login-button");
  // const emailInput = document.querySelector("#email-input");

  // loginButton.addEventListener("click", () => {
  //   const email = emailInput.value;

  //   // Make a request to the API to check if the email exists
  //   fetch("/api/check-email-exists?email=" + email)
  //     .then((response) => response.json())
  //     .then((data) => {
  //       if (!data.exists) {
  //         // Show an alert message if the email does not exist
  //         alert("Email does not exist in the database");
  //       } else {
  //         // Continue with the login process
  //         // ...
  //       }
  //     })
  //     .catch((error) => {
  //       console.error("Error checking email existence:", error);
  //     });
  // });
}

// Forgot_Password_Validation
// ********************************

const form = document.querySelector('form');
const emaill = document.querySelector('#email');
const newPassword = document.querySelector('#new-password');
const confirmPasswordd = document.querySelector('#confirm-password');
const submitButton = document.querySelector('#submit');
function ForgotPassword() {
  form.addEventListener('submit', function (event) {
    // Check if the email is not blank and is a valid email address
    if (emaill.validity.valueMissing) {
      alert('T37 - Email - Enter Registered Email');
      event.preventDefault();
    }

    // Check if the new password is not blank
    if (newPassword.validity.valueMissing) {
      alert('T38 - New Password - New Password must not be blank');
      event.preventDefault();
    }

    // Check if the new password contains at least one numeric value
    const regexNumeric = /[0-9]/g;
    if (!newPassword.value.match(regexNumeric)) {
      alert('T39 - New Password - Enter at-least one numeric value');
      event.preventDefault();
    }

    // Check if the new password contains at least one special character
    const regexSpecial = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/g;
    if (!newPassword.value.match(regexSpecial)) {
      alert('T40 - New Password - Enter at-least one special character');
      event.preventDefault();
    }

    // Check if the confirm password is not blank
    if (confirmPasswordd.validity.valueMissing) {
      alert('T41 - Confirm Password - Confirm Password must not be blank');
      event.preventDefault();
    }

    // Check if the new password and confirm password match
    if (newPassword.value !== confirmPasswordd.value) {
      alert('T42 - New Password and confirm Password must Match');
      event.preventDefault();
    }
  });


}

const forgotemailInput = document.getElementById('Forgotemail');
const forgotpasswordInput = document.getElementById('new-password');
const confirmpasswordInput = document.getElementById('confirm-password');
function validateforgot() {
  console.log()
  const forgotemailValue = forgotemailInput.value.trim();
  if (forgotemailValue === '') {
    alert('Email must not be blank');
  } else {
    return true;
  }
  const forgotpasswordValue = forgotpasswordInput.value.trim();
  if (forgotpasswordValue === '') {
    alert('Password must not be blank');
  } else
   {return true;} 
   if (forgotpasswordInput.value !== confirmpasswordInput.value) {
    alert(' New Password and confirm Password must Match');}
    else 
     {
      return true;
    }

  }













